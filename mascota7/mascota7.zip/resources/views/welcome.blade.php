@extends('layouts.app')

@section('content')


                <div class="panel-body">

@include('carousel')
  @endsection
